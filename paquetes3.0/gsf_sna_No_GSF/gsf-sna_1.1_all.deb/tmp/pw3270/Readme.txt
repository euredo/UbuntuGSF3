 dpkg -i lib3270_5.1-0_amd64.deb
 dpkg -i pw3270_5.1-0_amd64.deb
 dpkg -i pw3270-plugin-dbus_5.1-0_amd64.deb

Ejecuta en el usuario pw3270 y modificar la linea de comandos
